function changeImg()
{

document.getElementById('theimg').src="images/headphonesback.png";

}
function changeImgBack()
{

document.getElementById('theimg').src="images/headphones.png";
}
