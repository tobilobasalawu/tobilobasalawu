function changePicture()
{

document.getElementById('thepicture').src="images/unknown2.png";
}
function changePictureBack()
{

document.getElementById('thepicture').src="images/googlepixel.png";
}
