function changeBackground (theColor){
  document.getElementById("midarea").style.backgroundColor=theColor;}